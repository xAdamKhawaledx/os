#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/init_task.h>
#include <linux/types.h>
#include <linux/capability.h>
#include <linux/pid.h>
#include <linux/cred.h>


asmlinkage long sys_hello(void){
    printk("Hello, World!\n");
    return 0;
}

asmlinkage long sys_set_sec(int sword, int midnight, int clamp, int duty, int isolate){
   if(sword<0 || midnight<0 || clamp<0 || duty<0 || isolate<0){
        return -EINVAL;
    }
    if (!capable(CAP_SYS_ADMIN)){
        return -EPERM;
    }

    current->clr=0;
    if(sword){
        current->clr |= (1<<0);
    }
    if(midnight){
        current->clr |= (1<<1);
    }
    if(clamp){
        current->clr |= (1<<2);
    }
    if(duty){
        current->clr |= (1<<3);
    }
    if(isolate){
        current->clr |= (1<<4);
    }
	return 0;
}

asmlinkage long sys_get_sec(char clr){

    switch (clr) {
        case 's':
            return !(!(current->clr & (1 << 0)));
        case 'm':
            return !(!(current->clr & (1 << 1)));
        case 'c':
            return !(!(current->clr & (1 << 2)));
        case 'd':
            return !(!(current->clr & (1 << 3)));
        case 'i':
            return !(!(current->clr & (1 << 4)));
    }
return -EINVAL;
}

asmlinkage long sys_check_sec(pid_t pid, char clr){
if(!(clr == 'c' || clr =='m' || clr=='s' || clr=='d' || clr=='i')){
	return -EINVAL;
}
    struct task_struct* target = find_task_by_vpid(pid);
   if(!target){
        return -ESRCH;
    }
    if(sys_get_sec(clr)!=1){
        return -EPERM;
    }
    int i_bit=0;
    switch (clr) {
        case 's':
            i_bit=0;
	        break;
        case 'm':
            i_bit=1;
            break;
        case 'c':
	        i_bit=2;
            break;
        case 'd':
            i_bit=3;
            break;
        case 'i':
            i_bit=4;
            break;
        default:
            return -EINVAL;
    }
    return (target->clr & (1<<i_bit));
}


asmlinkage long sys_flip_sec_branch(int height, char clr){
    if(height<=0){
        return -EINVAL;
    }
    int i_bit=0;
    switch (clr) {
        case 's':
           i_bit=0;
	       break;
        case 'm':
            i_bit=1;
            break;
        case 'c':
            i_bit-2;
            break;
        case 'd':
            i_bit=3;
            break;
        case 'i':
            i_bit=4;
            break;
        default:
            return -EINVAL;
    }
    if(sys_get_sec(clr)!=1){
        return -EPERM;
    }
    struct task_struct* father = current->parent;
    int i = height;
    int c = 0;
    while(father && i>=1){
       if(!sys_check_sec(father->pid, clr)){
            father->clr |= (1<<i_bit);
            c++;

        }
       else{
           father->clr |= (0<<i_bit);
       }
	   i--;
       father=father->parent;
    }
    return c;
}

