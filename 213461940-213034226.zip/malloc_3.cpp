#include <iostream>
#include <vector>
#include <cmath>
#include <unistd.h>
#include <sys/mman.h>
#include <cstring>
#include <algorithm>
#include <cstdint>

// ------ Buddy Allocator Implementation ------

const size_t MAX_ORDER = 10;               // Orders 0...10.
const size_t BLOCK_SIZE = 128 * 1024;        // 128kb: the size of blocks at order MAX_ORDER.
const size_t MMAP_THRESHOLD = BLOCK_SIZE;    // Use mmap for allocations >= 128kb.
static bool inited = false;
static int totalblocks=32;

// Our buddy metadata structure. (Make sure its size is <= 64 bytes.)
struct BuddyBlock {
    size_t size;       // Total size of this block (including metadata).
    bool is_free;      
    size_t order;      // Order: 0 corresponds to smallest blocks (128 bytes) up to MAX_ORDER.
    // We maintain pointers for doubly–linked free list.
    BuddyBlock* prev;
    BuddyBlock* next;
};

// Global free-lists: free_lists[i] holds a list of blocks of order i, sorted by increasing memory address.
std::vector<BuddyBlock*> free_lists(MAX_ORDER + 1, nullptr);
// For blocks allocated via mmap.
std::vector<BuddyBlock*> mmap_blocks;
// Global list to track all blocks (both free and allocated).

// Forward declarations.
void insert_free_block(BuddyBlock* block);
void remove_free_block(BuddyBlock* block);

// --- Helper Functions ---

// Returns the pointer to the buddy using the XOR trick.
// (We assume that the entire region is aligned to (32*BLOCK_SIZE).)
inline BuddyBlock* get_buddy(BuddyBlock* block) {
    return (BuddyBlock*)((uintptr_t)block ^ block->size);
}

// Remove a block from its free list.
void remove_free_block(BuddyBlock* block) {
    if (block->prev)
        block->prev->next = block->next;
    else
        free_lists[block->order] = block->next;
    if (block->next)
        block->next->prev = block->prev;
    block->prev = block->next = nullptr;
}

// Insert a block into the free list for its order (keeping address–order).
void insert_free_block(BuddyBlock* block) {
    block->is_free = true;
    block->prev = block->next = nullptr;
    BuddyBlock* head = free_lists[block->order];
    // Insert in sorted order by address.
    if (!head) {
        free_lists[block->order] = block;
        return;
    }
    // If the new block comes before the head.
    if ((uintptr_t)block < (uintptr_t)head) {
        block->next = head;
        head->prev = block;
        free_lists[block->order] = block;
        return;
    }
    // Otherwise, find the proper place.
    BuddyBlock* current = head;
    while (current->next && (uintptr_t)current->next < (uintptr_t)block) {
        current = current->next;
    }
    block->next = current->next;
    if (current->next)
        current->next->prev = block;
    current->next = block;
    block->prev = current;
}

// --- Initialization ---
// We allocate 32 blocks of size BLOCK_SIZE from sbrk(), ensuring proper alignment.
void buddy_init() {
    // Align the starting address to a multiple of (32 * BLOCK_SIZE)
    void* current = sbrk(0);
    size_t alignment = 32 * BLOCK_SIZE;
    uintptr_t cur = (uintptr_t)current;
    size_t misalignment = cur % alignment;
    if (misalignment != 0) {
        size_t pad = alignment - misalignment;
        // This sbrk call is only for alignment and should not count in statistics.
        sbrk(pad);
    }
    // Now allocate 32 blocks.
    void* heap_start = sbrk(32 * BLOCK_SIZE);
    if (heap_start == (void*)-1) {
        std::cerr << "sbrk failed in buddy_init\n";
        exit(1);
    }
    // Create 32 blocks (all are free, of order MAX_ORDER).
    for (int i = 0; i < 32; ++i) {
        BuddyBlock* block = (BuddyBlock*)((char*)heap_start + i * BLOCK_SIZE);
        block->size = BLOCK_SIZE;
        block->is_free = true;
        block->order = MAX_ORDER;
        block->prev = block->next = nullptr;
        // Insert at the head of free_lists[MAX_ORDER] (they will be sorted by address by construction).
        insert_free_block(block);
    }
}

// --- Splitting a Block ---
// Splits a block into two buddies of half the size.
void split_block(BuddyBlock* block) {
    // Remove block from its free list.
    remove_free_block(block);
    

    size_t new_size = block->size / 2;
    size_t new_order = block->order - 1;
    
    // The block remains at the same address; its buddy is at address: block XOR new_size.
    BuddyBlock* buddy = (BuddyBlock*)((char*)block + new_size);
    
    // Initialize both halves.
    block->size = new_size;
    block->order = new_order;
    block->is_free = true;
    
    buddy->size = new_size;
    buddy->order = new_order;
    buddy->is_free = true;
    buddy->prev = buddy->next = nullptr;
    totalblocks++;
    // Insert both blocks into the free list.
    insert_free_block(block);
    insert_free_block(buddy);
    
}

// --- Merging Buddies ---
// Merge the block with its buddy if possible. Iteratively merge upward.
void merge_buddies(BuddyBlock* block) {
    // Try merging until we reach MAX_ORDER.
    while (block->order < MAX_ORDER) {
        BuddyBlock* buddy = get_buddy(block);
        // To be mergeable, buddy must be free and of the same order.
        if (!(buddy->is_free && buddy->order == block->order))
            break;
        // Remove buddy (and block) from free list.
        remove_free_block(buddy);
        remove_free_block(block);
        // Ensure the merged block is at the lower address.
        if ((uintptr_t)buddy < (uintptr_t)block)
            block = buddy;
        // Merge: new size is double; order increases by one.
        block->size *= 2;
        block->order += 1;
        // Mark as free.
        block->is_free = true;
        // Insert merged block into free list.
        insert_free_block(block);
	totalblocks--;
        // Remove the merged buddy from the global list.
       
    }
}

// --- Allocation Functions ---

// smalloc: allocate memory of at least "size" bytes.
void* smalloc(size_t size) {
    if (size == 0 || size+sizeof(BuddyBlock) > 128 * 1024 * 1024)
        return nullptr;
    if (!inited) {
        buddy_init();
        inited = true;
    }
    // For large requests, use mmap.
    if (size >= MMAP_THRESHOLD) {
        void* ptr = mmap(nullptr, size + sizeof(BuddyBlock),
                         PROT_READ | PROT_WRITE,
                         MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (ptr == MAP_FAILED)
            return nullptr;
        BuddyBlock* block = (BuddyBlock*)ptr;
        block->size = size;
        block->is_free = false;
        block->order = 0; // not used for mmap blocks.
        block->prev = block->next = nullptr;
        mmap_blocks.push_back(block);
        return (void*)(block + 1);
    }

    // Make sure that the buddy system has been initialized.
    

    // Compute the total needed size (user size + metadata).
    size_t needed = size + sizeof(BuddyBlock);
    // Find the minimal order that yields a block of at least "needed" bytes.
    size_t order = 0;
    size_t block_size = BLOCK_SIZE >> (MAX_ORDER - order); // smallest block size = BLOCK_SIZE >> MAX_ORDER.
    while (order <= MAX_ORDER && block_size < needed) {
        order++;
        block_size = BLOCK_SIZE >> (MAX_ORDER - order);
    }
    if (order > MAX_ORDER)
        return nullptr; // request too big for our pre-allocated buddy region.
    
    // Look for a free block in free_lists from order upward.
    BuddyBlock* block = nullptr;
    for (size_t o = order; o <= MAX_ORDER; ++o) {
        if (free_lists[o] != nullptr) {
            // Because our free list is sorted by address,
            // the head is the minimal address.
            block = free_lists[o];
            break;
        }
    }
    if (!block)
        return nullptr;
    
    // Iteratively split until we reach the desired order.
    while (block->order > order) {
        split_block(block);
        // After splitting, remove_free_block(block) was done; now choose the block with the lower address.
        // Because we inserted both halves, the one at the lower address is the original block.
        block = free_lists[block->order];
        if(block == nullptr)
		return nullptr;
    }
    // Remove chosen block from free list.
    remove_free_block(block);
    block->is_free = false;
    return (void*)(block + 1);
}

// sfree: free memory previously allocated with smalloc.
void sfree(void* p) {
    if (!p)
        return;
    BuddyBlock* block = (BuddyBlock*)p - 1;
    // If allocated with mmap (size field is less than BLOCK_SIZE? Here we set order==0 for mmap blocks)
    if (block->size >= MMAP_THRESHOLD && block->order == 0) {
        munmap(block, block->size + sizeof(BuddyBlock));
        mmap_blocks.erase(std::remove(mmap_blocks.begin(), mmap_blocks.end(), block),
                          mmap_blocks.end());
        return;
    }
    // Mark the block as free and insert it in the free list.
    block->is_free = true;
    insert_free_block(block);
    // Merge with buddy blocks if possible.
    merge_buddies(block);
}

// srealloc: reallocate block pointed to by oldp to have at least "size" bytes.
void* srealloc(void* oldp, size_t size) {
    if (!oldp)
        return smalloc(size);
    if (size == 0) {
        sfree(oldp);
        return nullptr;
    }
    BuddyBlock* old_block = (BuddyBlock*)oldp - 1;
    // For mmap blocks, always allocate a new one if size changes.
    if (old_block->size >= MMAP_THRESHOLD && old_block->order == 0) {
        if (old_block->size == size)
            return oldp;
        void* newp = smalloc(size);
        if (!newp)
            return nullptr;
        memcpy(newp, oldp, std::min(old_block->size, size));
        sfree(oldp);
        return newp;
    }
    // Check if current block is big enough.
    if (old_block->size >= size + sizeof(BuddyBlock))
        return oldp;
    // Otherwise, allocate a new block, copy data and free old block.
    void* newp = smalloc(size);
    if (!newp)
        return nullptr;
    memcpy(newp, oldp, old_block->size);
    sfree(oldp);
    return newp;
}

// scalloc: allocate and zero initialize an array.
void* scalloc(size_t num, size_t size) {
    size_t total = num * size;
    void* ptr = smalloc(total);
    if (ptr)
        memset(ptr, 0, total);
    return ptr;
}

// --- Statistics Functions ---
size_t _num_free_blocks() {
    if(!inited)
	return 0;
    size_t count = 0;
    for (size_t i = 0; i <= MAX_ORDER; ++i) {
        BuddyBlock* current = free_lists[i];
        while (current) {
                count++;
            current = current->next;
        }
    }
    return count;
}

size_t _num_free_bytes() {
    if(!inited)
	return 0;	
    size_t bytes = 0;
    for (size_t i = 0; i <= MAX_ORDER; ++i) {
        BuddyBlock* current = free_lists[i];
        while (current) {
                bytes += current->size;
            current = current->next;
        }
    }
    return bytes-_num_free_blocks()*sizeof(BuddyBlock);
}

size_t _num_allocated_blocks() {
    if(!inited)
	return 0;
    return  totalblocks + mmap_blocks.size();
}

size_t _num_allocated_bytes() {
    if(!inited)
	return 0;
    size_t bytes = 128*1024*32-totalblocks*sizeof(BuddyBlock);
    for (auto& a : mmap_blocks)
        bytes += a->size;
    return bytes;
}

size_t _num_meta_data_bytes() {
    if(!inited)
	return 0;
    return _num_allocated_blocks() * sizeof(BuddyBlock);
}

size_t _size_meta_data() {
    return sizeof(BuddyBlock);
}