#include <iostream>
#include <unistd.h>
#include <cstring>  // For memset

void* smalloc(size_t size) {
    if (size == 0 || size > 100000000) { // 10^8 bytes = 100,000,000
        return nullptr;
    }

    void* allocated_memory = sbrk(size);
    if (allocated_memory == (void*)-1) {
        return nullptr;
    }

    return allocated_memory;
}

