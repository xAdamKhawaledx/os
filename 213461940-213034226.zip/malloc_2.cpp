#include <unistd.h>
#include <cstring>
#define TEN_POW_8 100000000 

// Metadata structure for each memory block
struct MallocMetadata {
    size_t size;
    bool is_free;
    MallocMetadata* next;
    MallocMetadata* prev;
};

// Global pointer to the start of the metadata list
MallocMetadata* metadata_head = nullptr;

// Helper function to get the metadata from a block pointer
MallocMetadata* get_metadata(void* block) {
    return (MallocMetadata*)((char*)block - sizeof(MallocMetadata));
}

// Allocate memory
void* smalloc(size_t size) {
    if (size == 0 || size > TEN_POW_8) {
        return nullptr;
    }

    // Search for a free block in the metadata list
    MallocMetadata* current = metadata_head;
    while (current != nullptr) {
        if (current->is_free && current->size >= size) {
            current->is_free = false;
            return (char*)current + sizeof(MallocMetadata);
        }
        current = current->next;
    }

    // Allocate a new block using sbrk
    size_t total_size = size + sizeof(MallocMetadata);
    void* new_block = sbrk(total_size);
    if (new_block == (void*)-1) {
        return nullptr;
    }

    // Initialize the new metadata
    MallocMetadata* new_metadata = (MallocMetadata*)new_block;
    new_metadata->size = size;
    new_metadata->is_free = false;
    new_metadata->next = nullptr;
    new_metadata->prev = nullptr;

    // Insert the block into the list in a sorted manner
    if (metadata_head == nullptr) {
        metadata_head = new_metadata;
    } else {
        MallocMetadata* prev = nullptr;
        current = metadata_head;
        while (current != nullptr) {
            prev = current;
            current = current->next;
        }
        prev->next = new_metadata;
        new_metadata->prev = prev;
    }

    return (char*)new_metadata + sizeof(MallocMetadata);
}

// Allocate and zero-initialize memory
void* scalloc(size_t num, size_t size) {
    size_t total_size = num * size;
    if (total_size == 0 || total_size > TEN_POW_8) {
        return nullptr;
    }

    void* ptr = smalloc(total_size);
    if (ptr == nullptr) {
        return nullptr;
    }

    memset(ptr, 0, total_size);
    return ptr;
}

// Free memory
void sfree(void* p) {
    if (p == nullptr) {
        return;
    }

    MallocMetadata* metadata = get_metadata(p);
    metadata->is_free = true;
}

// Reallocate memory
void* srealloc(void* oldp, size_t size) {
    if (size == 0 || size > TEN_POW_8) {
        return nullptr;
    }

    if (oldp == nullptr) {
        return smalloc(size);
    }

    MallocMetadata* old_metadata = get_metadata(oldp);
    if (old_metadata->size >= size) {
        return oldp;
    }

    void* newp = smalloc(size);
    if (newp == nullptr) {
        return nullptr;
    }

    memmove(newp, oldp, old_metadata->size);
    sfree(oldp);

    return newp;
}

// Stats functions
size_t _num_free_blocks() {
    size_t count = 0;
    MallocMetadata* current = metadata_head;
    while (current != nullptr) {
        if (current->is_free) {
            count++;
        }
        current = current->next;
    }
    return count;
}

size_t _num_free_bytes() {
    size_t bytes = 0;
    MallocMetadata* current = metadata_head;
    while (current != nullptr) {
        if (current->is_free) {
            bytes += current->size;
        }
        current = current->next;
    }
    return bytes;
}

size_t _num_allocated_blocks() {
    size_t count = 0;
    MallocMetadata* current = metadata_head;
    while (current != nullptr) {
        count++;
        current = current->next;
    }
    return count;
}

size_t _num_allocated_bytes() {
    size_t bytes = 0;
    MallocMetadata* current = metadata_head;
    while (current != nullptr) {
        bytes += current->size;
        current = current->next;
    }
    return bytes;
}

size_t _size_meta_data() {
    return sizeof(MallocMetadata);
}

size_t _num_meta_data_bytes() {
    return _size_meta_data() * _num_allocated_blocks();
}