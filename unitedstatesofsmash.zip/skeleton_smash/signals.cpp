#include <iostream>
#include <signal.h>
#include "signals.h"
#include "Commands.h"

using namespace std;

int foreground_pid = -1;

void ctrlCHandler(int sig_num) {
    // Print the message indicating that Ctrl+C was received
    std::cout << "\nsmash: got ctrl-C\n";

    if (foreground_pid > 0) {
        if (kill(foreground_pid, SIGKILL) == 0) {
            std::cout << "smash: process " << foreground_pid << " was killed\n";
        } else {
            perror("smash error: kill failed");
        }

        foreground_pid = -1;
    }
}