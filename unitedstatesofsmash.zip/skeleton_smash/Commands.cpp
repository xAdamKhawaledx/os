#include <unistd.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <iomanip>
#include "Commands.h"
#include <limits.h>
#include <regex>

using namespace std;

const std::string WHITESPACE = " \n\r\t\f\v";

#if 0
#define FUNC_ENTRY()  \
  cout << __PRETTY_FUNCTION__ << " --> " << endl;

#define FUNC_EXIT()  \
  cout << __PRETTY_FUNCTION__ << " <-- " << endl;
#else
#define FUNC_ENTRY()
#define FUNC_EXIT()
#endif

string _ltrim(const std::string &s) {
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}

string _rtrim(const std::string &s) {
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string _trim(const std::string &s) {
    return _rtrim(_ltrim(s));
}

int _parseCommandLine(const char *cmd_line, char **args) {
    FUNC_ENTRY()
    int i = 0;
    std::istringstream iss(_trim(string(cmd_line)).c_str());
    for (std::string s; iss >> s;) {
        args[i] = (char *) malloc(s.length() + 1);
        memset(args[i], 0, s.length() + 1);
        strcpy(args[i], s.c_str());
        args[++i] = NULL;
    }
    return i;

    FUNC_EXIT()
}

bool _isBackgroundComamnd(const char *cmd_line) {
    const string str(cmd_line);
    return str[str.find_last_not_of(WHITESPACE)] == '&';
}

void _removeBackgroundSign(char *cmd_line) {
    const string str(cmd_line);
    // find last character other than spaces
    unsigned int idx = str.find_last_not_of(WHITESPACE);
    // if all characters are spaces then return
    if (idx == string::npos) {
        return;
    }
    // if the command line does not end with & then return
    if (cmd_line[idx] != '&') {
        return;
    }
    // replace the & (background sign) with space and then remove all tailing spaces.
    cmd_line[idx] = ' ';
    // truncate the command line string up to the last non-space character
    cmd_line[str.find_last_not_of(WHITESPACE, idx) + 1] = 0;
}

// TODO: Add your implementation for classes in Commands.h 


/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/
Command *SmallShell::CreateCommand(const char *cmd_line) {
    std::string cmd_s = _trim(std::string(cmd_line)); // Trim the input
    if (cmd_s.empty()) {
        return nullptr; // Ignore empty input
    }

    // Check for background execution
    bool isBackground = _isBackgroundComamnd(cmd_s.c_str());
    char cmd_copy[COMMAND_MAX_LENGTH];
    strcpy(cmd_copy, cmd_line);
    if (isBackground) {
        _removeBackgroundSign(cmd_copy); // Remove '&' if it's a background command
        cmd_s = _trim(std::string(cmd_copy));
    }

    // Extract the first word of the command (command name)
    std::string firstWord = cmd_s.substr(0, cmd_s.find_first_of(" \n"));

    // Check if the command name is an alias
    auto &aliases = SmallShell::getInstance().aliases;
    if (aliases.find(firstWord) != aliases.end()) {
        // Replace the command line with the alias value
        std::string aliasCommand = aliases[firstWord];
        std::string expandedCommand = aliasCommand + cmd_s.substr(firstWord.size());
        return CreateCommand(expandedCommand.c_str()); // Recurse with the expanded alias
    }

    // Handle built-in commands
    if (firstWord == "chprompt") {
        return new ChpromptCommand(cmd_line);
    } else if (firstWord == "showpid") {
        return new ShowPidCommand(cmd_line);
    } else if (firstWord == "pwd") {
        return new GetCurrDirCommand(cmd_line);
    } else if (firstWord.compare("cd") == 0) {
        char temp[PATH_MAX];
        if (getcwd(temp, sizeof(temp)) != nullptr) {
            return new ChangeDirCommand(cmd_line, &lastPwd);
        }       
        else {
                perror("smash error: getcwd failed");
                return nullptr;
            }
    } else if (firstWord == "jobs") {
        return new JobsCommand(cmd_line, jobs);
    } else if (firstWord == "fg") {
        return new ForegroundCommand(cmd_line, jobs);
    } else if (firstWord == "quit") {
        return new QuitCommand(cmd_line, jobs);
    } else if (firstWord == "kill") {
        return new KillCommand(cmd_line, jobs);
    } else if (firstWord == "alias") {
        return new AliasCommand(cmd_line);
    } else if (firstWord == "unalias") {
        return new UnaliasCommand(cmd_line);
    }

    // If command is not recognized as a built-in command, treat it as external
    return new ExternalCommand(cmd_line);
}


//done
void ChpromptCommand::execute() {
    // Parse the command line to extract the prompt argument
    char *args[COMMAND_MAX_ARGS];
    int argCount = _parseCommandLine(cmd_line, args);

    // Set the new prompt (if an argument is provided)
    if (argCount > 1) {
        SmallShell::getInstance().setPrompt(args[1]);
    } else {
        SmallShell::getInstance().setPrompt("smash"); // Reset to default
    }

    // Free allocated memory for args
    for (int i = 0; i < argCount; ++i) {
        free(args[i]);
    }
}

//done
void ShowPidCommand::execute() {
    SmallShell &smash = SmallShell::getInstance();
    std::cout << "smash pid is " << smash.getSmashPid() << std::endl;
}

//done
void GetCurrDirCommand::execute() {
    char cwd[PATH_MAX]; 
    if (getcwd(cwd, sizeof(cwd)) != nullptr) {
        std::cout << cwd << std::endl;
    } else {
        perror("smash error: getcwd failed"); 
    }
}

//done
void ChangeDirCommand::execute() {
    char *args[COMMAND_MAX_ARGS];
    int argc = _parseCommandLine(cmd_line, args);

    if (argc == 1) { 
        // No arguments provided, do nothing
        for (int i = 0; i < argc; ++i) free(args[i]);
        return;
    }

    if (argc > 2) {
        // Too many arguments error
        std::cerr << "smash error: cd: too many arguments" << std::endl;
        for (int i = 0; i < argc; ++i) free(args[i]);
        return;
    }

    std::string path = args[1];
    if (path == "-") {
        if (*lastPwd == nullptr) {
            std::cerr << "smash error: cd: OLDPWD not set" << std::endl;
        } else {
            char temp[PATH_MAX];
            if (getcwd(temp, sizeof(temp)) != nullptr) {
                if (chdir(*lastPwd) == -1) {
                    perror("smash error: chdir failed");
                } else {
                    strncpy(*lastPwd, temp, PATH_MAX);  
                }
            }
        }
    } else {
        char temp[PATH_MAX];
        if (getcwd(temp, sizeof(temp)) != nullptr) {
            if (chdir(path.c_str()) == -1) {
                perror("smash error: chdir failed");
            } else {
                if (*lastPwd == nullptr) {
                    *lastPwd = (char *)malloc(PATH_MAX);
                }
                strncpy(*lastPwd, temp, PATH_MAX); 
            }
        }
    }

    for (int i = 0; i < argc; ++i) free(args[i]);
}
void AliasCommand::execute() {
    std::string input(cmd_line);
    std::smatch match;
    auto &aliases = SmallShell::getInstance().aliases;
    // Match the input with the required alias format
    std::regex aliasRegex("^alias ([a-zA-Z0-9_]+)='([^']*)'$");

    // If only 'alias' is provided, print all aliases
    if (input == "alias") {
        for (const auto &entry : aliases) {
            std::cout << entry.first << "='" << entry.second << "'" << std::endl;
        }
        return;
    }

    if (!std::regex_match(input, match, aliasRegex)) {
        // Invalid format
        std::cerr << "smash error: alias: invalid alias format" << std::endl;
        return;
    }

    std::string aliasName = match[1];
    std::string aliasCommand = match[2];

    // Check for reserved keywords
    SmallShell &shell = SmallShell::getInstance();
    if (shell.isReservedCommand(aliasName) || aliases.find(aliasName) != aliases.end()) {
        std::cerr << "smash error: alias: " << aliasName << " already exists or is a reserved command" << std::endl;
        return;
    }

    // Add the alias
    aliases[aliasName] = aliasCommand;
}
std::vector<std::string> getArgs(const char *cmd_line) {
    std::istringstream iss(cmd_line);
    std::vector<std::string> args;
    std::string token;
    while (iss >> token) {
        args.push_back(token);
    }
    return args;
}

void UnaliasCommand::execute() {
    std::vector<std::string> args = getArgs(cmd_line);
    auto &aliases = SmallShell::getInstance().aliases;
    if (args.size() <= 1) {
        std::cerr << "smash error: unalias: not enough arguments" << std::endl;
        return;
    }

    for (size_t i = 1; i < args.size(); ++i) {
        const std::string &alias_name = args[i];

        if (aliases.find(alias_name) == aliases.end()) {
        
            std::cerr << "smash error: unalias: " << alias_name << " alias does not exist" << std::endl;
            return;
        }

        aliases.erase(alias_name); // Remove alias from the map
    }
}

//done
void QuitCommand::execute() {
    char *args[COMMAND_MAX_ARGS];
    int argCount = _parseCommandLine(cmd_line, args);

    // Check for "kill" argument
    bool shouldKill = (argCount >= 2 && std::string(args[1]) == "kill");

    if (shouldKill && jobs) {
        std::cout << "smash: sending SIGKILL signal to " << jobs->getJobsCount() << " jobs:" << std::endl;
        jobs->killAllJobs();
    }

    // Free parsed arguments
    for (int i = 0; i < argCount; ++i) {
        free(args[i]);
    }

    exit(0);
}


void JobsCommand::execute() 
{
        jobs->printJobsList();
}

void KillCommand::execute() {
    char *args[COMMAND_MAX_ARGS];
    int argCount = _parseCommandLine(cmd_line, args);

    // Check for correct syntax (should have exactly 3 arguments: kill -<signum> <job-id>)
    if (argCount != 3 || args[1][0] != '-') {
        std::cerr << "smash error: kill: invalid arguments" << std::endl;
        for (int i = 0; i < argCount; ++i) free(args[i]);
        return;
    }

    int signum, jobId;

    // Extract the signal number and job ID
    try {
        signum = std::stoi(std::string(args[1] + 1)); // Skip the '-' in -<signum>
        jobId = std::stoi(args[2]);
    } catch (...) {
        std::cerr << "smash error: kill: invalid arguments" << std::endl;
        for (int i = 0; i < argCount; ++i) free(args[i]);
        return;
    }

    // Retrieve the job by job ID
    JobsList::JobEntry *job = jobs->getJobById(jobId);
    if (!job) {
        std::cerr << "smash error: kill: job-id " << jobId << " does not exist" << std::endl;
        for (int i = 0; i < argCount; ++i) free(args[i]);
        return;
    }

    // Send the signal to the job's process
    if (kill(job->pid, signum) == -1) {
        perror("smash error: kill failed");
    } else {
        std::cout << "signal number " << signum << " was sent to pid " << job->pid << std::endl;
    }

    // Free allocated memory
    for (int i = 0; i < argCount; ++i) free(args[i]);
}


void ForegroundCommand::execute() {
    char *args[COMMAND_MAX_ARGS];
    int argCount = _parseCommandLine(cmd_line, args);

    // Handle invalid arguments (more than 2 arguments or invalid format)
    if (argCount > 2) {
        std::cerr << "smash error: fg: invalid arguments" << std::endl;
        for (int i = 0; i < argCount; ++i) free(args[i]);
        return;
    }

    int jobId = -1;

    // If job-id is provided, parse it
    if (argCount == 2) {
        try {
            jobId = std::stoi(args[1]); // Convert argument to integer
        } catch (...) {
            std::cerr << "smash error: fg: invalid arguments" << std::endl;
            for (int i = 0; i < argCount; ++i) free(args[i]);
            return;
        }
    }

    // If no job-id is provided, bring the job with the highest ID
    if (jobId == -1) {
        int lastJobId;
        auto lastJob = jobs->getLastJob(&lastJobId);
        if (!lastJob) {
            std::cerr << "smash error: fg: jobs list is empty" << std::endl;
            for (int i = 0; i < argCount; ++i) free(args[i]);
            return;
        }
        jobId = lastJobId;
    }

    // Retrieve the job by ID
    JobsList::JobEntry *job = jobs->getJobById(jobId);
    if (!job) {
        std::cerr << "smash error: fg: job-id " << jobId << " does not exist" << std::endl;
        for (int i = 0; i < argCount; ++i) free(args[i]);
        return;
    }

    // Print job info
    std::cout << job->command << " " << job->pid << std::endl;

    // Send SIGCONT if the job is stopped
    if (job->isStopped) {
        if (kill(job->pid, SIGCONT) == -1) {
            perror("smash error: kill failed");
            for (int i = 0; i < argCount; ++i) free(args[i]);
            return;
        }
        job->isStopped = false;
    }

    // Wait for the job to finish in the foreground
    int status;
    if (waitpid(job->pid, &status, WUNTRACED) == -1) {
        perror("smash error: waitpid failed");
    }

    // If the process was stopped, mark it as stopped; otherwise, remove the job
    if (WIFSTOPPED(status)) {
        job->isStopped = true;
    } else {
        jobs->removeJobById(jobId);
    }

    // Free allocated memory
    for (int i = 0; i < argCount; ++i) free(args[i]);
}


void ExternalCommand::execute() {
    pid_t pid = fork();  // Fork a new child process

    if (pid == -1) {
        // Fork failed
        perror("smash error: fork failed");
        return;
    }

    if (pid == 0) {
        // Child process
        setpgrp();  // Detach from parent's process group

        // Detect if the command contains wildcards (* or ?)
        std::string cmd_s(cmd_line);
        if (cmd_s.find('*') != std::string::npos || cmd_s.find('?') != std::string::npos) {
            // Complex command: execute using /bin/bash -c
            execl("/bin/bash", "bash", "-c", cmd_s.c_str(), nullptr);
            perror("smash error: execl failed");
            exit(1);
        }

        // Simple external command: parse the command line into arguments
        std::vector<char*> args;
        char* cmd_copy = strdup(cmd_line);  // Duplicate the command line for parsing
        char* token = strtok(cmd_copy, " \t\n");  // Tokenize the command line

        while (token != nullptr) {
            args.push_back(token);
            token = strtok(nullptr, " \t\n");
        }
        args.push_back(nullptr);  // Null-terminate the argument list

        // Execute the command using execvp
        execvp(args[0], args.data());
        perror("smash error: execvp failed");
        free(cmd_copy);  // Free allocated memory
        exit(1);
    } else {
        // Parent process
        if (_isBackgroundComamnd(cmd_line)) {
            // Background execution: Add job to jobs list
            SmallShell::getInstance().jobs->addJob(this, false);
            std::cout << "smash: background job added with PID " << pid << std::endl;
        } else {
            // Foreground execution: Wait for the child process
            if (waitpid(pid, nullptr, WUNTRACED) == -1) {
                perror("smash error: waitpid failed");
            }
        }
    }
}

 /*void SmallShell::executeCommand(const char *cmd_line) {
    // TODO: Add your implementation here
    // for example:
    // Command* cmd = CreateCommand(cmd_line);
    // cmd->execute();
    // Please note that you must fork smash process for some commands (e.g., external commands....)
if (cmd_line == nullptr || strlen(cmd_line) == 0) {
        return; // Ignore empty input
    }

    Clean up and process the command line
    char cmd_line_copy[COMMAND_MAX_LENGTH];
    strcpy(cmd_line_copy, cmd_line);

    bool isBackground = _isBackgroundComamnd(cmd_line_copy);
    _removeBackgroundSign(cmd_line_copy);  
    std::string trimmedCmd = _trim(cmd_line_copy);

    if (trimmedCmd.empty()) {
        return; // Do nothing for empty commands
    }

    // Create the appropriate command
    Command *cmd = CreateCommand(cmd_line_copy);
    if (cmd == nullptr) {
        return; // Command could not be created
    }

    // Execute the command
    cmd->execute();

    // If the command is running in the background, add it to jobs list
    if (isBackground) {
        // TODO: Add implementation to handle jobs in background
    }

    delete cmd; // Clean up the command object
}*/
void SmallShell::executeCommand(const char *cmd_line) {
    // Check if the command is empty
    std::string cmd(cmd_line);
    if (cmd.empty()) {
        return;
    }

    // Detect background command
    bool isBackground = _isBackgroundComamnd(cmd.c_str());
    char cmd_copy[COMMAND_MAX_LENGTH];
    strcpy(cmd_copy, cmd_line); // Make a mutable copy of the command line

    if (isBackground) {
        _removeBackgroundSign(cmd_copy); // Remove '&' from the command
    }

    std::string trimmedCmd = _trim(std::string(cmd_copy));

    // Create the appropriate command object
    Command *cmdObj = CreateCommand(trimmedCmd.c_str());
    if (!cmdObj) {
        return; // Command not recognized
    }

    if (dynamic_cast<ExternalCommand *>(cmdObj) && isBackground) {
        // External command in the background
        pid_t pid = fork();

        if (pid == -1) {
            perror("smash error: fork failed");
            delete cmdObj;
            return;
        }

        if (pid == 0) {
            // Child process
            setpgrp(); // Set a new process group
            
            cmdObj->execute(); // Execute the external command
            exit(0); // Exit child process after execution
        } else {
            // Parent process: Add the background job to the jobs list
            jobs->addJob(cmdObj, false);
            std::cout << "smash: background job added with PID " << pid << std::endl;
        }
    } else {
        // Foreground execution for all built-in commands and external commands
        cmdObj->execute();
    }

    delete cmdObj; // Clean up the command object
}
bool SmallShell::isReservedCommand(const std::string &name) {
    static const std::vector<std::string> reserved = {
        "chprompt", "showpid", "pwd", "cd", "quit", "jobs", "kill",
        "fg", "bg", "alias", "unalias", "listdir", "whoami"
    };

    return std::find(reserved.begin(), reserved.end(), name) != reserved.end();
}

void SmallShell::printAliases() {
    for (const auto &entry : aliases) {
        std::cout << entry.first << "='" << entry.second << "'" << std::endl;
    }
}

//SPECIAL YOU ARE MY SBESHOL

struct ParsedCommand {
    std::string command;
    std::string output_file;
    bool append_mode = false;
    bool has_redirection = false;
};

ParsedCommand parseRedirection(const std::string &cmd_line) {
    ParsedCommand result;
    size_t redirection_pos = cmd_line.find('>');
    if (redirection_pos != std::string::npos) {
        result.has_redirection = true;

        // Check if it's '>>'
        if (cmd_line[redirection_pos + 1] == '>') {
            result.append_mode = true;
            redirection_pos++; 
        }

        // Split command and file
        result.command = cmd_line.substr(0, redirection_pos);
        result.output_file = cmd_line.substr(redirection_pos + 1);
        trim(result.command);    
        trim(result.output_file);
    } else {
        result.command = cmd_line;
    }
    return result;
}
void redirectOutput(const std::string &file_name, bool append_mode) {
    int flags = O_WRONLY | O_CREAT | (append_mode ? O_APPEND : O_TRUNC);
    int fd = open(file_name.c_str(), flags, 0644);
    if (fd == -1) {
        perror("smash error: open failed");
        exit(1);
    }

    if (dup2(fd, STDOUT_FILENO) == -1) { 
        perror("smash error: dup2 failed");
        close(fd);
        exit(1);
    }
    close(fd); 
}
void executeCommandWithRedirection(const ParsedCommand &parsed) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("smash error: fork failed");
        return;
    }

    if (pid == 0) {
        
        setpgrp(); 

        
        if (parsed.has_redirection) {
            redirectOutput(parsed.output_file, parsed.append_mode);
        }

        
        std::vector<std::string> args = getArgs(parsed.command.c_str());
        std::vector<char *> exec_args;
        for (const std::string &arg : args) {
            exec_args.push_back(const_cast<char *>(arg.c_str()));
        }
        exec_args.push_back(nullptr); 

        if (execvp(exec_args[0], exec_args.data()) == -1) {
            perror("smash error: execvp failed");
            exit(1);
        }
    } else {
        
        if (waitpid(pid, nullptr, WUNTRACED) == -1) {
            perror("smash error: waitpid failed");
        }
    }
}
void listDirectory(const std::string &path, int depth) {
    DIR *dir = opendir(path.c_str());
    if (!dir) {
        perror("smash error: listdir");
        return;
    }

    std::vector<std::string> directories;
    std::vector<std::string> files;

    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;

        // Skip the current directory (.) and parent directory (..)
        if (name == "." || name == "..") continue;

        std::string fullPath = path + "/" + name;

        struct stat statBuf;
        if (stat(fullPath.c_str(), &statBuf) == -1) {
            perror("smash error: listdir");
            closedir(dir);
            return;
        }

        if (S_ISDIR(statBuf.st_mode)) {
            directories.push_back(name);
        } else {
            files.push_back(name);
        }
    }

    closedir(dir);

    // Sort directories and files alphabetically
    std::sort(directories.begin(), directories.end());
    std::sort(files.begin(), files.end());

    // Print directories first, then files
    for (const auto &dirName : directories) {
        std::cout << std::string(depth, '\t') << dirName << "\n";
        listDirectory(path + "/" + dirName, depth + 1); // Recursive call
    }
    for (const auto &fileName : files) {
        std::cout << std::string(depth, '\t') << fileName << "\n";
    }
}

void executeListdirCommand(const std::string &cmd_line) {
    // Parse the command line
    std::istringstream iss(cmd_line);
    std::vector<std::string> tokens{std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};

    if (tokens.size() > 2) {
        std::cerr << "smash error: listdir: too many arguments\n";
        return;
    }

    std::string directoryPath = (tokens.size() == 1) ? "." : tokens[1];
    listDirectory(directoryPath, 0);
}
void executeWhoamiCommand(const std::string &cmd_line) {
    std::istringstream iss(cmd_line);
    std::vector<std::string> tokens{std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>{}};

    if (tokens.size() > 1) {
    }

    struct passwd *pw = getpwuid(getuid());
    if (!pw) {
        perror("smash error: whoami");
        return;
    }
    std::string username = pw->pw_name;

    std::string homeDir = pw->pw_dir;

    std::cout << username << " " << homeDir << "\n";
}
void executePipeCommand(const std::string& command) {
    size_t pipePos = command.find("|");
    if (pipePos == std::string::npos) {
        std::cerr << "Invalid pipe command" << std::endl;
        return;
    }

    bool isStderrPipe = (command.find("|&") != std::string::npos);
    std::string command1 = command.substr(0, pipePos);
    std::string command2 = command.substr(pipePos + (isStderrPipe ? 2 : 1));

    auto trim = [](std::string& str) {
        str.erase(0, str.find_first_not_of(" \t"));
        str.erase(str.find_last_not_of(" \t") + 1);
    };
    trim(command1);
    trim(command2);

    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("smash error: pipe failed");
        return;
    }

    pid_t pid1 = fork();
    if (pid1 == -1) {
        perror("smash error: fork failed");
        return;
    }
    if (pid1 == 0) {
        if (isStderrPipe) {
            dup2(pipefd[1], STDERR_FILENO);
        } else {
            dup2(pipefd[1], STDOUT_FILENO);
        }
        close(pipefd[0]);
        close(pipefd[1]);
        execlp("/bin/bash", "bash", "-c", command1.c_str(), nullptr);
        perror("smash error: exec failed");
        exit(1);
    }

    pid_t pid2 = fork();
    if (pid2 == -1) {
        perror("smash error: fork failed");
        return;
    }
    if (pid2 == 0) {
        dup2(pipefd[0], STDIN_FILENO);
        close(pipefd[0]);
        close(pipefd[1]);
        execlp("/bin/bash", "bash", "-c", command2.c_str(), nullptr);
        perror("smash error: exec failed");
        exit(1);
    }

    close(pipefd[0]);
    close(pipefd[1]);
    waitpid(pid1, nullptr, 0);
    waitpid(pid2, nullptr, 0);
}