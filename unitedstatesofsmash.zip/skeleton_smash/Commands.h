#ifndef SMASH_COMMAND_H_
#define SMASH_COMMAND_H_

#include <vector>
#include <list>
#include <map>
#include <string>
#include <memory>
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <cstring> 
#include <cstdlib>   


#define COMMAND_MAX_LENGTH (200)
#define COMMAND_MAX_ARGS (20)

class Command {
public:
    const char *cmd_line;

    Command(const char *cmd_line) : cmd_line(cmd_line) {}

    virtual ~Command() {}

    virtual void execute() = 0;
};

class BuiltInCommand : public Command {
public:
    BuiltInCommand(const char *cmd_line) : Command(cmd_line) {}

    virtual ~BuiltInCommand() {}
};

class ExternalCommand : public Command {
public:
    ExternalCommand(const char *cmd_line) : Command(cmd_line) {}

    virtual ~ExternalCommand() {}

    void execute() override;
};

class PipeCommand : public Command {
public:
    PipeCommand(const char *cmd_line) : Command(cmd_line) {}

    virtual ~PipeCommand() {}

    void execute() override;
};

class RedirectionCommand : public Command {
public:
    explicit RedirectionCommand(const char *cmd_line) : Command(cmd_line) {}

    virtual ~RedirectionCommand() {}

    void execute() override;
};

class ChangeDirCommand : public BuiltInCommand {
    char **lastPwd;

public:
    ChangeDirCommand(const char *cmd_line, char **plastPwd)
        : BuiltInCommand(cmd_line), lastPwd(plastPwd) {}

    virtual ~ChangeDirCommand() {}

    void execute() override;
};

class GetCurrDirCommand : public BuiltInCommand {
public:
    GetCurrDirCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}

    virtual ~GetCurrDirCommand() {}

    void execute() override;
};

class ShowPidCommand : public BuiltInCommand {
public:
    ShowPidCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}

    virtual ~ShowPidCommand() {}

    void execute() override;
};

class JobsList {
public:
    class JobEntry {
    public:
        int jobId;
        pid_t pid;             // Process ID
        std::shared_ptr<Command> command; // Command associated with the job
        bool isStopped;        // Is the job stopped or running?

        JobEntry(int jobId, pid_t pid, std::shared_ptr<Command> command, bool isStopped)
            : jobId(jobId), pid(pid), command(command), isStopped(isStopped) {}
    };

private:
    std::list<std::shared_ptr<JobEntry>> jobs;
    int nextJobId;

public:
    JobsList() : nextJobId(1) {}

    ~JobsList() {
        killAllJobs();
    }
    int getJobsCount() const {
    return jobs.size();
}
    void addJob(Command *cmd, bool isStopped = false) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork failed");
        return;
    }
    if (pid == 0) {
        // Child process: Execute the external command
        setpgrp();

        // Parse the command line into arguments
        std::vector<char*> args;
        char* cmd_copy = strdup(cmd->cmd_line);  // Make a mutable copy
        char* token = strtok(cmd_copy, " \t\n"); // Tokenize command line

        while (token != nullptr) {
            args.push_back(token);
            token = strtok(nullptr, " \t\n");
        }
        args.push_back(nullptr); // Null-terminate arguments list

        // Execute the command
        execvp(args[0], args.data());
        perror("execlp failed");
        free(cmd_copy);
        exit(1); // Exit if execvp fails
    } else {
        // Parent process: Add the job to the list
        jobs.push_back(std::make_shared<JobEntry>(nextJobId++, pid, std::shared_ptr<Command>(cmd), isStopped));
        std::cout << "Job added with PID: " << pid << "\n";
    }
}

    void printJobsList() {
        removeFinishedJobs();
        if (jobs.empty()) {
            return;
        }
        for (const auto &job : jobs) {
            std::cout << "[" << job->jobId
                      << "]" 
                      << " " << job->command->cmd_line
                      << std::endl;
        }
    }

   void killAllJobs() {
    for (auto &job : jobs) {
        std::cout << job->pid << ": " << job->command << std::endl;
        if (kill(job->pid, SIGKILL) == -1) {
            perror("smash error: kill failed");
        }
    }
    jobs.clear();
}

    void removeFinishedJobs() {
    if (jobs.empty()) {
            return;
        }
    for (auto it = jobs.begin(); it != jobs.end();) {
        int status;
        pid_t result = waitpid((*it)->pid, &status, WNOHANG);

        if (result == -1) {
            perror("smash error: waitpid failed");
            it = jobs.erase(it);
        } else if (result > 0) {
            it = jobs.erase(it);
        } else {
            ++it;
        }
    }
}



    JobEntry *getJobById(int jobId) {
        for (auto &job : jobs) {
            if (job->jobId == jobId) {
                return job.get();
            }
        }
        return nullptr;
    }

    void removeJobById(int jobId) {
        for (auto it = jobs.begin(); it != jobs.end(); ++it) {
            if ((*it)->jobId == jobId) {
                jobs.erase(it);
                std::cout << "Removed job ID " << jobId << "\n";
                return;
            }
        }
    }

    JobEntry *getLastJob(int *lastJobId) {
        if (jobs.empty()) {
            return nullptr;
        }
        *lastJobId = jobs.back()->jobId;
        return jobs.back().get();
    }

    JobEntry *getLastStoppedJob(int *jobId) {
        for (auto it = jobs.rbegin(); it != jobs.rend(); ++it) {
            if ((*it)->isStopped) {
                *jobId = (*it)->jobId;
                return it->get();
            }
        }
        return nullptr;
    }
};

class QuitCommand : public BuiltInCommand {
    JobsList *jobs;

public:
    QuitCommand(const char *cmd_line, JobsList *jobs)
        : BuiltInCommand(cmd_line), jobs(jobs) {}

    virtual ~QuitCommand() {}

    void execute() override;
};

class JobsCommand : public BuiltInCommand {
    JobsList *jobs;

public:
    JobsCommand(const char *cmd_line, JobsList *jobs)
        : BuiltInCommand(cmd_line), jobs(jobs) {}

    virtual ~JobsCommand() {}

    void execute() override;
};

class KillCommand : public BuiltInCommand {
    JobsList *jobs;

public:
    KillCommand(const char *cmd_line, JobsList *jobs)
        : BuiltInCommand(cmd_line), jobs(jobs) {}

    virtual ~KillCommand() {}

    void execute() override;
};

class ForegroundCommand : public BuiltInCommand {
    JobsList *jobs;

public:
    ForegroundCommand(const char *cmd_line, JobsList *jobs)
        : BuiltInCommand(cmd_line), jobs(jobs) {}

    virtual ~ForegroundCommand() {}

    void execute() override;
};

class SmallShell {
public:
    int smash_pid;
    std::string currentPrompt;
    char *lastPwd; // To store OLDPWD
    std::map<std::string, std::string> aliases;
    JobsList *jobs;

    SmallShell() : smash_pid(getpid()), currentPrompt("smash"), lastPwd(nullptr), jobs(new JobsList()) {}

public:
    SmallShell(const SmallShell &) = delete;
    void operator=(const SmallShell &) = delete;

    static SmallShell &getInstance() {
        static SmallShell instance;
        return instance;
    }

    ~SmallShell() { delete jobs; }

    const std::string &getPrompt() const { return currentPrompt; }
    void setPrompt(const std::string &newPrompt) { currentPrompt = newPrompt; }
    int getSmashPid() const { return smash_pid; }
    Command *CreateCommand(const char *cmd_line);
    void executeCommand(const char *cmd_line);
    void printAliases();
    bool isReservedCommand(const std::string &name);
};

class ChpromptCommand : public BuiltInCommand {
public:
    ChpromptCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};

class AliasCommand : public BuiltInCommand {
public:
    AliasCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};
class UnaliasCommand : public BuiltInCommand {
public:
    UnaliasCommand(const char *cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};

#endif // SMASH_COMMAND_H_
